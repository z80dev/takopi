after you finish work, commit with a conventional message. only commit the files you edited.
run `make check` and fix any errors before committing.

