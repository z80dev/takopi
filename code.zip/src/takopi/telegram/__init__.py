"""Telegram-specific clients and adapters."""
