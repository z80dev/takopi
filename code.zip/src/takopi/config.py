from __future__ import annotations


class ConfigError(RuntimeError):
    pass
