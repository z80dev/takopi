"""Utility helpers for Takopi."""
