"""Event schemas for runner JSONL streams."""
